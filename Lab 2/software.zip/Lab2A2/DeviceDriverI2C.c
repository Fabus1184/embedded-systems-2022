/***************************************************************************
 * DeviceDriverI2C.c
 *
 * Device driver for open-core I2C controller (www.opencores.org). Driver
 * implements following functions:
 *   I2C_init()  - Device initialization
 *   I2C_open()  - Reservation and application specific initialization
 *   I2C_close() - Release and default initialization
 *   I2C_write() - Send/write data to I2C slave
 *   I2C_read()  - Receive/read data from I2C slave
 *
 * Authors: D. Kirchner, T. Schwarz, M. Strahnen
 *
 *  Edition History:
 *  2017-09-11: Delay I2C_DEL01 after each I2C cycles introduced - ms
 *  2017-09-13: More and hopefully better comments - ms
 ***************************************************************************/

/**************************         includes        **************************/
#include <stdlib.h>
#include <unistd.h>				// required for usleep()
#include "DeviceDriverI2C.h"

/**************************         defines         **************************/
#define I2C_BASE	0xff204040	// I2C controller's base address
#define I2C_PRERLO 	(*((volatile uint8_t *) (I2C_BASE+0x00))) // I2C Prescale register 8 bit
#define I2C_PRERHI 	(*((volatile uint8_t *) (I2C_BASE+0x04))) // I2C Prescale register 8 bit
#define I2C_CTR 	(*((volatile uint8_t *) (I2C_BASE+0x08))) // Controlregister 8 bit
#define I2C_TXR 	(*((volatile uint8_t *) (I2C_BASE+0x0c))) // transmit 8 bit register
#define I2C_RXR 	(*((volatile uint8_t *) (I2C_BASE+0x0c))) // receive 8 bit register
#define I2C_CR 		(*((volatile uint8_t *) (I2C_BASE+0x10))) // command register
#define I2C_SR 		(*((volatile uint8_t *) (I2C_BASE+0x10))) // status register

#define CTR_EN_BIT  0x80     	// I2cEnable bit in I2C control register Bit 7
#define CR_STA_BIT  0x80       	// STArt bit in I2C command register Bit 7
#define CR_STO_BIT  0x40        // STOp  bit in I2C command register Bit 6
#define CR_RD_BIT  	0x20        // ReaD  bit in I2C command register bit 5
#define CR_WR_BIT  	0x10        // WRite bit in I2C command register bit 4
#define CR_ACK_BIT  0x08       	// ACKnowledge bit I2C command register bit 3
								// CR_ACK_BIT = '0' means an acknowledge,
								// CR_ACK_BIT = '1' means a 'not acknowledge'
#define SR_ACK_BIT  0x80		// ACKnowledge bit in I2C status register,
								// SR_ACK_BIT = '0' means that a positive
								// acknowledge has been received
#define SR_TIP_BIT 	0x02        // Transfer In progress (TIP) bit in I2C status
								// status register. SR_TIP_BIT = '0' means that
								// transfer has completed

#define PRESCALE400   0x31		// Prescaler for I2C clock speed = 400 kHz
#define PRESCALE100   0xc7		// Prescaler for I2C clock speed = 100 kHz

#define I2C_DEL01	40			// Delay in us between successive cycles

Device_States I2C_Stat = NOTAVAIL;			// Device State before INIT

/**************************************************************
 * 	Helper Function:	I2C_basicInit()
 * 	Description:	Basic initialization of the I2C controller,
 * 					so that it does not disturb the system.
 * 	Parameter:		-
 *  Return:			void
 *************************************************************/
void I2C_basicInit(void)
{
	I2C_PRERLO = 0xFF;		// Reset speed of I2C LowByte
	I2C_PRERHI = 0xFF;		// Reset speed 0 of I2C HighByte
	I2C_CTR = 0x00;			// Reset Control Register
	I2C_TXR = 0x00;			// Reset Transmit / Receive Register
	I2C_CR = 0x00;			// Reset Command Register
}

/**************************************************************
 * 	Function:		I2C_init()
 * 	Description:	Initialization of the I2C controller.
 * 	                I2C_init() normally is called only once,
 * 	                during boot-up or initialization of the
 * 	                computer system.
 * 	Parameter:		-
 *  Return:			int (Errorcode)
 *       0: successful operation
 *      -1: wrong initial state
 *************************************************************/
int I2C_init(void)
{
	if(I2C_Stat != NOTAVAIL) {
		return(-1);
	}

	I2C_basicInit();		// basic initialization
	I2C_Stat = INIT;		// Set Device State INIT

	return 0;
}

/**************************************************************
 * 	Function:		I2C_open()
 * 	Description:	Reservation of I2C controller and application
 * 	    specific initialization. Initialization concerns the
 * 	    used I2C clock rate. Only following two clock rates
 * 	    are supported:
 * 	    - 400 kHz (value I2CSPEED400),
 * 	    - 100 kHz (value I2CSPEED100).
 * 	Parameter:		int16_t i2c_speed (I2C clock rate)
 *  Return:			int (Errorcode)
 *       0: successful operation
 *      -1: device not initialized
 *      -2: illegal I2C clock rate
 **************************************************************/
int I2C_open(int16_t i2c_speed)
{
	if(I2C_Stat != INIT){
		return -1;							// device not initalized or in use
	}

	switch(i2c_speed) {
	case I2CSPEED400:	// I2C clock rate = 400 kHz
		I2C_PRERLO = 0xff & PRESCALE400;		// Set speed of I2C LowByte
		I2C_PRERHI = 0xff & (PRESCALE400>>8);	// Set speed of I2C HighByte
		break;
	case I2CSPEED100:	// I2C clock rate = 100 kHz
		I2C_PRERLO = 0xff & PRESCALE100;		// Set speed of I2C LowByte
		I2C_PRERHI = 0xff & (PRESCALE100>>8);	// Set speed of I2C HighByte
		break;
	default:
		return(-2);
	}

	I2C_CTR = CTR_EN_BIT;		// Enable I2C controller
	I2C_Stat = ACTIVE;			// set device status to "ACTIVE"
	return 0;
}

/**************************************************************
 * 	Function:		I2C_close()
 * 	Description:	Release device and default initialization
 * 	Parameter:		-
 *  Return:			int (Errorcode)
 *     0: successful operation
 **************************************************************/
int I2C_close(void)
{
	if(I2C_Stat != ACTIVE){
		return -1;				// device not initalized or in use
	}

	I2C_basicInit();		// basic initialization
	I2C_Stat = INIT;
	return 0;
}

/**************************************************************
 * 	Function:		I2C_write()
 * 	Description:	Send/Write of passed data byte i2c_data to
 * 	                I2C slave with address i2c_address.
 *                  i2c_data has to be the ADC control byte
 *                  which starts measurement and which fixes
 *                  ADC input channel. Following control bytes
 *                  are applicable:
 *
 *                  control byte | selected channel
 *                  -------------|-----------------
 *                      0x80     |   channel 0
 *                      0x81     |   channel 1
 *                      0x82     |   channel 2
 *                      0x83     |   channel 3
 *
 * 	Parameter:		uint8_t i2c_address (7 bit I2C slave address),
 * 	                uint8_t i2c_data (8 bit data byte).
 *
 *  Return:			int (Errorcode)
 *      0: successful operation
 *     -1: device not active
 *     -2: no ack after sending i2c_address
 *     -3: no ack after sending i2c_data
 **************************************************************/
int I2C_write(uint8_t i2c_address, uint8_t i2c_data)
{
	if(I2C_Stat != ACTIVE){
		return -1;						// ERROR: Device not Open
	}

	I2C_TXR = (i2c_address << 1) | 0x00;	// Set slave's I2C address and
											// indicate an I2C write cycle
	I2C_CR = CR_STA_BIT | CR_WR_BIT;  	// Set I2C start bit and
										// command of an I2C send byte operation
	while ( I2C_SR & SR_TIP_BIT) ;		// wait till done
	if (I2C_SR & SR_ACK_BIT) {  		// Test slave's acknowlege
		return -2;              		// ERROR: no ACK has been received
	}

	// send data byte
	I2C_TXR = i2c_data;       			// Write data byte
	I2C_CR = CR_WR_BIT;            		// execute I2C send operation
	while (I2C_SR & SR_TIP_BIT);   		// wait till done

	if (I2C_SR & SR_ACK_BIT){       	// Test slave's acknowledge
	  I2C_CR = CR_STO_BIT;				// No acknowledge
	  return -3;                 		// ERROR: no ACK has been received
	}

	I2C_CR = CR_STO_BIT;				// Write Stop Condition
	while (I2C_SR & SR_TIP_BIT);   		// wait till done

	// Between successive cycles there should be a certain delay
	usleep(I2C_DEL01);

	return 0;
}

/**************************************************************
 * 	Function:		I2C_read()
 * 	Description:	Receives/reads a 16 Bit data word from an
 * 	                I2C slave with address i2c_address. Data
 * 	                word is stored at the address given by
 * 	                i2c_data.
 * 	Parameter:		uint8_t i2c_address (7 bit I2C slave address),
 * 	                uint8_t *i2c_data (address of 16 Bit data word)
 *  Return:			int (Errorcode)
 *      0: successful operation
 *     -1: device not active
 *     -2: no ack after sending i2c_address
 *     -3: i2c_data is a null pointer
 **************************************************************/
int I2C_read(uint8_t i2c_address, uint16_t *i2c_data)
{
	uint16_t data_U = 0x0;
	uint16_t data_L = 0x0;

	if(I2C_Stat != ACTIVE){
		return -1;				//ERROR: Device not Open
	}

	if(i2c_data == NULL) {		// check for legal pointer
		return -3;
	}

	I2C_TXR = (i2c_address << 1) | 0x01;	// Set slave's I2C address and
											// indicate an I2C write cycle
	I2C_CR = CR_STA_BIT | CR_WR_BIT;  	// Set I2C start bit and
										// command of an I2C send byte operation

	while ( I2C_SR & SR_TIP_BIT); 		// wait till done
	if (I2C_SR & SR_ACK_BIT)  			// Test slave's acknowlege
		return -2;              		// ERROR: no ACK has been received

	I2C_CR = CR_RD_BIT;					// command of an I2C receive byte operation
	while (I2C_SR & SR_TIP_BIT);		// wait till done
	data_U = I2C_RXR;					// save received (Upper) byte

	I2C_CR = CR_RD_BIT;					// send ACK to slave (CR_ACK_BIT = '0' and
										// command of next I2C receive byte operation
	while (I2C_SR & SR_TIP_BIT);		// wait till done
	data_L = I2C_RXR;					// save received (Lower) byte

	I2C_CR = CR_STO_BIT | CR_ACK_BIT;	// Send NACK and Stop Condition

	while (I2C_SR & SR_TIP_BIT);   		// wait till done

	*i2c_data = (data_U << 4) | (data_L >> 4);	// compose and store
												// received data
	// Between successive cycles there should be a certain delay
	usleep(I2C_DEL01);

	return 0;
}
