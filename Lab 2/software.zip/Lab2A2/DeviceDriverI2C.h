/**************************************************************
 * DeviceDriverI2C.h
 *
 * Contains any kind of definition and prototype declaration
 * required to use I2C device driver.
 * File has to be included by applications which want to use
 * I2C device driver DeviceDriverI2C.h.
 *
 * Authors: D. Kirchner, T. Schwarz, M. Strahnen
 *
 *  Edition History:
 *  2017-09-11: I2CSPEEDxxx values included - ms
 **************************************************************/

#ifndef DEVICEDRIVERI2C_H_
#define DEVICEDRIVERI2C_H_

/**************************         includes        **************************/
#include <stdint.h>

/**************************    DeviceDriverDefines     **************************/
typedef enum { NOTAVAIL, INIT, ACTIVE }Device_States;

#define I2CSPEED400	400			// value to adjust I2C clock rate to 400 kHz
#define I2CSPEED100	100			// value to adjust I2C clock rate to 100 kHz

/**************************     Methods    **************************/
extern int I2C_init(void);
extern int I2C_open(int16_t i2c_speed);
extern int I2C_close(void);
extern int I2C_write(uint8_t i2c_address, uint8_t i2c_data);
extern int I2C_read(uint8_t i2c_address, uint16_t *i2c_data);

#endif /* DEVICEDRIVERI2C_H_ */
